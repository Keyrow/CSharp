﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            // ...all womens' leagues
            ViewBag.WomenLeague = context.Leagues
                .Where(l => l.Name.Contains("Women"));
            // ...all leagues where sport is any type of hockey
            ViewBag.HockeyLeague = context.Leagues
                .Where(l => l.Sport.Contains("Hockey"));
            // ...all leagues where sport is something OTHER THAN football
            ViewBag.HockeyLeague = context.Leagues
                .Where(l => !l.Sport.Contains("Football"));
            // ...all leagues that call themselves "conferences"
            ViewBag.Conferences = context.Leagues
                .Where(l => l.Name.Contains("Conference"));
            // ...all leagues in the Atlantic region
            ViewBag.Atlantic = context.Leagues
                .Where(l => l.Name.Contains("Atlantic"));
            // ...all teams based in Dallas
            ViewBag.Dallas = context.Teams
                .Where(t => t.Location.Contains("Dallas"));
            // ...all teams named the Raptors
            ViewBag.Raptors = context.Teams
                .Where(t => t.TeamName.Contains("Raptors"));
            // ...all teams whose location includes "City"
            ViewBag.City = context.Teams
                .Where(t => t.Location.Contains("City"));
            // ...all teams whose names begin with "T"
            ViewBag.Tee = context.Teams
                .Where(t => t.TeamName.Contains("T"));
            // ...all teams, ordered alphabetically by location
            ViewBag.Alpha = context.Teams
                .OrderBy(l => l.Location);
            // ...all teams, ordered by team name in reverse alphabetical order
            ViewBag.ReverseAlpha = context.Teams
                .OrderByDescending(l => l.TeamName);
            // ...every player with last name "Cooper"
            ViewBag.Cooper = context.Players
                .Where(l => l.LastName.Contains("Cooper"));
            // ...every player with first name "Joshua"
            ViewBag.Joshua = context.Players
                .Where(l => l.FirstName.Contains("Joshua"));
            // ...every player with last name "Cooper" EXCEPT those with "Joshua" as the first name
            ViewBag.Joshua2 = context.Players
                .Where(l => l.LastName.Contains("Cooper") && l.FirstName != "Joshua");
            // ...all players with first name "Alexander" OR first name "Wyatt"
            ViewBag.AlexWyatt = context.Players
                .Where(l => l.FirstName.Contains("Alexander") || l.FirstName == "Wyatt");



            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}