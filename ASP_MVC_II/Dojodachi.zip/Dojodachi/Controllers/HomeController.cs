﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Dojodachi.Models;
using Newtonsoft.Json;

namespace Dojodachi.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet("")]
        public IActionResult Dojodachi()
        {
            if (HttpContext.Session.GetObjectFromJson<Pet>("myPet") == null)
            {

                Pet myPet = new Pet();

                HttpContext.Session.SetObjectAsJson("myPet", myPet);

                ViewBag.pet = HttpContext.Session.GetObjectFromJson<Pet>("myPet");
                return View();
            }
            else
            {
                Pet pet = HttpContext.Session.GetObjectFromJson<Pet>("myPet");
                Pet myPet = new Pet(pet.fullness, pet.happiness, pet.energy, pet.meals, pet.restart);

                ViewBag.pet = HttpContext.Session.GetObjectFromJson<Pet>("myPet");
                HttpContext.Session.SetObjectAsJson("myPet", myPet);
                return View();
            }
        }
        [HttpPost("Feed")]
        public IActionResult Feed()
        {
            Pet pet = HttpContext.Session.GetObjectFromJson<Pet>("myPet");
            Pet myPet = new Pet(pet.fullness, pet.happiness, pet.energy, pet.meals, pet.restart);
            myPet.Feed();
            HttpContext.Session.SetObjectAsJson("myPet", myPet);
            return RedirectToAction("Dojodachi");
        }
        [HttpPost("Play")]
        public IActionResult Play()
        {
            Pet pet = HttpContext.Session.GetObjectFromJson<Pet>("myPet");
            Pet myPet = new Pet(pet.fullness, pet.happiness, pet.energy, pet.meals, pet.restart);
            myPet.Play();
            HttpContext.Session.SetObjectAsJson("myPet", myPet);
            return RedirectToAction("Dojodachi");
        }
        [HttpPost("Work")]
        public IActionResult Work()
        {
            Pet pet = HttpContext.Session.GetObjectFromJson<Pet>("myPet");
            Pet myPet = new Pet(pet.fullness, pet.happiness, pet.energy, pet.meals, pet.restart);
            myPet.Work();
            HttpContext.Session.SetObjectAsJson("myPet", myPet);
            return RedirectToAction("Dojodachi");
        }
        [HttpPost("Sleep")]
        public IActionResult Sleep()
        {
            Pet pet = HttpContext.Session.GetObjectFromJson<Pet>("myPet");
            Pet myPet = new Pet(pet.fullness, pet.happiness, pet.energy, pet.meals, pet.restart);
            myPet.Sleep();
            HttpContext.Session.SetObjectAsJson("myPet", myPet);
            return RedirectToAction("Dojodachi");
        }

        [HttpPost("Restart")]
        public IActionResult Restart()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Dojodachi");

        }
    }
}

public static class SessionExtensions
{
    // We can call ".SetObjectAsJson" just like our other session set methods, by passing a key and a value
    public static void SetObjectAsJson(this ISession session, string key, object value)
    {
        // This helper function simply serializes theobject to JSON and stores it as a string in session
        session.SetString(key, JsonConvert.SerializeObject(value));
    }

    // generic type T is a stand-in indicating that we need to specify the type on retrieval
    public static T GetObjectFromJson<T>(this ISession session, string key)
    {
        string value = session.GetString(key);
        // Upon retrieval the object is deserialized based on the type we specified
        return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
    }
}

