using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;


namespace Dojodachi.Models
{
    public class Pet
    {
        public int happiness { get; set; }
        public int fullness { get; set; }
        public int energy { get; set; }
        public int meals { get; set; }
        public bool restart { get; set; }
        public string lastAction { get; set; }

        Random rand = new Random();
        public Pet()
        {
            happiness = 20;
            fullness = 20;
            energy = 50;
            meals = 3;
            restart = false;
        }

        public Pet(int happiness, int fullness, int energy, int meals, bool restart)
        {
            this.happiness = happiness;
            this.fullness = fullness;
            this.energy = energy;
            this.meals = meals;
            this.restart = restart;
        }

        public void Feed()
        {
            int x = rand.Next(5, 11);
            if (meals > 0)
            {
                meals -= 1;

                if (rand.Next(1, 5) != 1)
                {
                    fullness += x;
                    if (happiness >= 100 && energy >= 100 && fullness >= 100)
                    {
                        restart = true;
                        lastAction = "You Win";
                    }
                    else
                    {
                        lastAction = $"Dojodachi has eaten, fullness increased by {x} and you lost one meal.";
                    }
                }
                else
                {
                    lastAction = $"Dojodachi didn't like this food. No fullness gained. You just lost {x} amount of fullness";
                }
            }
            else
            {
                lastAction = "You don't have any meals.";
            }

        }
        public void Play()
        {
            int x = rand.Next(5, 11);
            if (energy > 5)
            {
                energy -= 5;

                if (rand.Next(1, 5) != 1)
                {
                    happiness += x;
                    if (happiness >= 100 && energy >= 100 && fullness >= 100)
                    {
                        System.Console.WriteLine("You win!");
                        restart = true;
                    }
                    else 
                    {
                        lastAction = $"Dojodachi has played, Happiness increased by {x} and you lost 5 energy.";
                    }
                }
                else
                {
                    lastAction = $"Dojodachi didn't like playing. No happiness gained.";
                }
            }
            else
            {
                lastAction = $"Dojodachi doesn't have enough energy to play.";
            }
        }
        public void Work()
        {
            if (energy >= 5)
            {
                int x = rand.Next(1, 4);
                meals += x;
                energy -= 5;
            }
            else
            {
                lastAction = $"You need more sleep. Energy is too low to work.";
            }
        }
        public void Sleep()
        {
            if (fullness <= 5 || happiness <= 5)
            {
                lastAction = "You lose! Loser!";
                restart = true;
            }
            else
            {
                energy += 15;
                fullness -= 5;
                happiness -= 5;
                if (happiness >= 100 && energy >= 100 && fullness >= 100)
                {
                    lastAction = "You win";
                    restart = true;
                }
            }
        }

    }

}


// Feeding your Dojodachi costs 1 meal and gains a random amount of fullness between 5 and 10 (you cannot feed your Dojodachi if you do not have meals)
// Playing with your Dojodachi costs 5 energy and gains a random amount of happiness between 5 and 10
// Every time you play with or feed your dojodachi there should be a 25% chance that it won't like it. Energy or meals will still decrease, but happiness and fullness won't change.
// Working costs 5 energy and earns between 1 and 3 meals
// Sleeping earns 15 energy and decreases fullness and happiness each by 5
// If energy, fullness, and happiness are all raised to over 100, you win! a restart button should be displayed.
// If fullness or happiness ever drop to 0, you lose, and a restart button should be displayed.