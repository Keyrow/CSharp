﻿using System;

class MainClass
{
    public static void Main(string[] args)
    {
        // For loop, start at 1, end at 255, re-iterating +1
        for (int input = 1; input <= 255; input++)
        {
            Console.WriteLine(input);
        }
    }
}
